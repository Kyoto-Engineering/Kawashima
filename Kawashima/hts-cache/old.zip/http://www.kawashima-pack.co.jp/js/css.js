

if (navigator.userAgent.indexOf("Mac")!=-1) {
	document.write("<link rel='stylesheet' href='css/mac.css' type='text/css'>");
} else {
	document.write("<link rel='stylesheet' href='css/win.css' type='text/css'>");
}

